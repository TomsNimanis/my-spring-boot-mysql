package com.okta.examples.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeyondAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
